class Animal {
  numLegs: number
}

class Bee extends Animal {

}

class Lion extends Animal {

}
