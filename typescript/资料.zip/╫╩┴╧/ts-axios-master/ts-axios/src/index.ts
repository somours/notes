import axios from './axios'

export * from './types'

export default axios
